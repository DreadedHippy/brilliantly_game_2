ELEMENTAL COMPANION IDLES

Earth tortoise, ember lion and wind owl are descriptive asset labels.
Each folder contains a 2-second idle, transparent PNG assets, WebP, metadata, original sources, prompts, provenance and exact QA.
Serve preview.html over HTTP; reduced motion starts paused.
Suggested silhouette display height: 80px.

Art review: the tortoise retains subtle-pose similarity warnings; elemental fringes have conservative margin/detached-effect warnings. The owl retains a head-size flag and measured torso drift despite a targeted image edit. Read each QA.md for every exact value, threshold, current report and preserved historical diagnostic.

Generated using built-in image generation. No level placement or following AI is included.
